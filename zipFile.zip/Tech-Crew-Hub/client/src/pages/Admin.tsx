import { Navbar } from "@/components/Navbar";
import { useUser } from "@/hooks/use-auth";
import { useEnquiries } from "@/hooks/use-enquiries";
import { useProperties, useDeleteProperty, useCreateProperty } from "@/hooks/use-properties";
import { useCars, useDeleteCar, useCreateCar } from "@/hooks/use-cars";
import { useState } from "react";
import { Loader2, Trash2, Plus, LayoutGrid, Car as CarIcon, MessageSquare, X } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPropertySchema, insertCarSchema } from "@shared/schema";

export default function Admin() {
  const { data: user, isLoading: authLoading } = useUser();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<'properties' | 'cars' | 'enquiries'>('properties');
  
  if (authLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-10 h-10 animate-spin text-primary"/></div>;
  if (!user) {
    setLocation("/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      <div className="pt-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <h1 className="text-3xl font-bold mb-8 font-display">Admin Dashboard</h1>
        
        <div className="flex space-x-4 mb-8">
          <button 
            onClick={() => setActiveTab('properties')} 
            className={`px-4 py-2 rounded-lg font-medium flex items-center ${activeTab === 'properties' ? 'bg-primary text-white' : 'bg-white text-muted-foreground hover:bg-slate-100'}`}
          >
            <LayoutGrid className="w-4 h-4 mr-2" /> Properties
          </button>
          <button 
            onClick={() => setActiveTab('cars')} 
            className={`px-4 py-2 rounded-lg font-medium flex items-center ${activeTab === 'cars' ? 'bg-primary text-white' : 'bg-white text-muted-foreground hover:bg-slate-100'}`}
          >
            <CarIcon className="w-4 h-4 mr-2" /> Cars
          </button>
          <button 
            onClick={() => setActiveTab('enquiries')} 
            className={`px-4 py-2 rounded-lg font-medium flex items-center ${activeTab === 'enquiries' ? 'bg-primary text-white' : 'bg-white text-muted-foreground hover:bg-slate-100'}`}
          >
            <MessageSquare className="w-4 h-4 mr-2" /> Enquiries
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-border p-6">
          {activeTab === 'properties' && <PropertiesManager />}
          {activeTab === 'cars' && <CarsManager />}
          {activeTab === 'enquiries' && <EnquiriesList />}
        </div>
      </div>
    </div>
  );
}

function PropertiesManager() {
  const { data: properties, isLoading } = useProperties();
  const { mutate: deleteProperty } = useDeleteProperty();
  const { mutate: createProperty, isPending: isCreating } = useCreateProperty();
  const { toast } = useToast();
  const [showAddForm, setShowAddForm] = useState(false);

  const form = useForm({
    resolver: zodResolver(insertPropertySchema),
    defaultValues: {
      title: "",
      description: "",
      type: "buy",
      location: "",
      price: 0,
      imageUrl: "",
      specs: { bedrooms: 1, bathrooms: 1, area: 500 },
      features: [],
      isFeatured: false
    }
  });

  const onSubmit = (data: any) => {
    createProperty(data, {
      onSuccess: () => {
        toast({ title: "Property Created" });
        setShowAddForm(false);
        form.reset();
      }
    });
  };

  if (isLoading) return <Loader2 className="animate-spin" />;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Manage Properties</h2>
        <button onClick={() => setShowAddForm(true)} className="flex items-center text-sm bg-primary text-white px-3 py-2 rounded-lg">
          <Plus className="w-4 h-4 mr-1" /> Add Property
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">Add New Property</h3>
              <button onClick={() => setShowAddForm(false)}><X className="w-6 h-6" /></button>
            </div>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Title</label>
                  <input {...form.register("title")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" placeholder="e.g. Modern Villa" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Type</label>
                  <select {...form.register("type")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all">
                    <option value="buy">Buy</option>
                    <option value="rent">Rent</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Location</label>
                  <input {...form.register("location")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" placeholder="e.g. Palm Jumeirah" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Price</label>
                  <input type="number" {...form.register("price", { valueAsNumber: true })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1 text-slate-700">Image URL</label>
                  <input {...form.register("imageUrl")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" placeholder="https://..." />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Bedrooms</label>
                  <input type="number" {...form.register("specs.bedrooms", { valueAsNumber: true })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Area (sqft)</label>
                  <input type="number" {...form.register("specs.area", { valueAsNumber: true })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" />
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <input type="checkbox" id="isFeatured" {...form.register("isFeatured")} className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary" />
                  <label htmlFor="isFeatured" className="text-sm font-medium text-slate-700">Featured Property</label>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-700">Description</label>
                <textarea {...form.register("description")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none transition-all" rows={3} placeholder="Describe the property details..." />
              </div>
              <button disabled={isCreating} className="w-full py-3 bg-primary text-white rounded-lg font-bold shadow-lg shadow-primary/20 hover:shadow-primary/30 active:scale-[0.98] transition-all disabled:opacity-50">
                {isCreating ? <Loader2 className="animate-spin mx-auto"/> : "Create Property"}
              </button>
            </form>
          </div>
        </div>
      )

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-muted-foreground">
            <tr>
              <th className="px-4 py-3 rounded-tl-lg">Title</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3 rounded-tr-lg">Actions</th>
            </tr>
          </thead>
          <tbody>
            {properties?.map(p => (
              <tr key={p.id} className="border-b border-border">
                <td className="px-4 py-3 font-medium">{p.title}</td>
                <td className="px-4 py-3 capitalize">{p.type}</td>
                <td className="px-4 py-3">${p.price.toLocaleString()}</td>
                <td className="px-4 py-3">
                  <button onClick={() => deleteProperty(p.id)} className="text-destructive hover:bg-destructive/10 p-2 rounded">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CarsManager() {
  const { data: cars, isLoading } = useCars();
  const { mutate: deleteCar } = useDeleteCar();
  const { mutate: createCar, isPending: isCreating } = useCreateCar();
  const { toast } = useToast();
  const [showAddForm, setShowAddForm] = useState(false);

  const form = useForm({
    resolver: zodResolver(insertCarSchema),
    defaultValues: {
      name: "",
      category: "economy",
      pricePerDay: 0,
      imageUrl: "",
      isAvailable: true,
      features: [],
      description: ""
    }
  });

  const onSubmit = (data: any) => {
    // If features is empty string, convert to array
    const formattedData = {
      ...data,
      features: typeof data.features === 'string' ? data.features.split(',').map((f: string) => f.trim()) : data.features
    };
    
    createCar(formattedData, {
      onSuccess: () => {
        toast({ title: "Car Created" });
        setShowAddForm(false);
        form.reset();
      }
    });
  };

  if (isLoading) return <Loader2 className="animate-spin" />;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Manage Cars</h2>
        <button onClick={() => setShowAddForm(true)} className="flex items-center text-sm bg-primary text-white px-3 py-2 rounded-lg">
          <Plus className="w-4 h-4 mr-1" /> Add Car
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">Add New Car</h3>
              <button onClick={() => setShowAddForm(false)}><X className="w-6 h-6" /></button>
            </div>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-700">Name</label>
                <input {...form.register("name")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none" placeholder="e.g. Tesla Model 3" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Category</label>
                  <select {...form.register("category")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none">
                    <option value="economy">Economy</option>
                    <option value="luxury">Luxury</option>
                    <option value="4x4">4x4 / SUV</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-slate-700">Price/Day</label>
                  <input type="number" {...form.register("pricePerDay", { valueAsNumber: true })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-700">Image URL</label>
                <input {...form.register("imageUrl")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none" placeholder="https://..." />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-slate-700">Description / Features</label>
                <textarea {...form.register("description")} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary/20 outline-none" rows={3} placeholder="e.g. Autopilot, Bluetooth, Sunroof..." />
              </div>
              <button disabled={isCreating} className="w-full py-3 bg-primary text-white rounded-lg font-bold shadow-lg shadow-primary/20 hover:shadow-primary/30 active:scale-[0.98] transition-all disabled:opacity-50">
                {isCreating ? <Loader2 className="animate-spin mx-auto"/> : "Create Car"}
              </button>
            </form>
          </div>
        </div>
      )

      <table className="w-full text-sm text-left">
        <thead className="bg-slate-50 text-muted-foreground">
          <tr>
            <th className="px-4 py-3 rounded-tl-lg">Name</th>
            <th className="px-4 py-3">Category</th>
            <th className="px-4 py-3">Price/Day</th>
            <th className="px-4 py-3 rounded-tr-lg">Actions</th>
          </tr>
        </thead>
        <tbody>
          {cars?.map(c => (
            <tr key={c.id} className="border-b border-border">
              <td className="px-4 py-3 font-medium">{c.name}</td>
              <td className="px-4 py-3 capitalize">{c.category}</td>
              <td className="px-4 py-3">${c.pricePerDay}</td>
              <td className="px-4 py-3">
                <button onClick={() => deleteCar(c.id)} className="text-destructive hover:bg-destructive/10 p-2 rounded">
                  <Trash2 className="w-4 h-4" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function EnquiriesList() {
  const { data: enquiries, isLoading } = useEnquiries();

  if (isLoading) return <Loader2 className="animate-spin" />;

  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Recent Enquiries</h2>
      <div className="space-y-4">
        {enquiries?.map(e => (
          <div key={e.id} className="p-4 rounded-lg border border-border hover:bg-slate-50 transition-colors">
            <div className="flex justify-between mb-2">
              <span className="font-bold">{e.name}</span>
              <span className="text-xs text-muted-foreground bg-slate-100 px-2 py-1 rounded-full capitalize">{e.type}</span>
            </div>
            <div className="text-sm text-muted-foreground mb-2">
              <a href={`mailto:${e.email}`} className="hover:text-primary mr-4">{e.email}</a>
              {e.phone && <span>{e.phone}</span>}
            </div>
            <p className="text-sm text-foreground bg-slate-50 p-3 rounded">{e.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
